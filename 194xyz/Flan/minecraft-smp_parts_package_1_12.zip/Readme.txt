Package Readme
-------------------------------------------------------------------------------
Name:				Minecraft-SMP Part Package

Version-No.:			1.6.4a
-------------------------------------------------------------------------------
Author:				Manus

Contact:			www.minecraft-smp.de
-------------------------------------------------------------------------------
Mc-Version:			1.6.4

Flans Mod Version:		3.1.2

Depencies:			-

Build with Forge Version:	1.6.4-9.11.0.886
-------------------------------------------------------------------------------
This Package is free to download on www.minecraft-smp.de. 

If you downloaded it somewhere else or payed for it (single or as part of a
compilation) please report this to manus@minecraft-smp.de.